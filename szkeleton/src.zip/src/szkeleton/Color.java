package szkeleton;

/**
 *Enum a szineknek
 * @author Adam
 */
public enum Color {
    BLUE, RED, YELLOW, PURPLE, GREEN, BLACK
}
