package szkeleton;

/**
 * Kivetelkezeleshez
 * @author Adam
 */
public class CrashException extends Exception {

    public CrashException() {
    }

    public CrashException(String message) {
        super(message);
    }
}
